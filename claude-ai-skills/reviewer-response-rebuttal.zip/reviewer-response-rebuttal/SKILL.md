---
name: reviewer-response-rebuttal
description: "Response-to-reviewers / rebuttal letter assistant for journal major or minor revisions. Use to: parse the editor's decision letter (must-do vs optional, major vs minor vs reject-and-resubmit); structure the response letter; write each reply in three parts (restate comment, explain change, quote revised text with page/line); keep a confident but respectful tone; push back politely with evidence; handle conflicting reviewers; respond to common requests (extra analyses, literature, theory, methods, causality, English editing); write the resubmission cover letter; check tracked changes. Triggers: reviewer comments, response to reviewers, rebuttal, major revision, minor revision, R&R, revise and resubmit, cover letter, الرد على المحكمين, التعديلات."
license: MIT
---

# 审稿意见回应 / Rebuttal 专项助手（Response to Reviewers）

一套聚焦**修回信/审稿回应**的深度助手——专门解决投稿人最焦虑的一步：**收到 major/minor revision 后，如何把一封逐条回应信写得让编辑和审稿人满意，把 R&R 转化为录用。**

> 一句话立场：**修回不是"改完就行"，而是一次"再说服"。** 一封好的回应信 = 尊重每一条意见 + 让审稿人零成本看到你改了什么 + 有理有据地处理你不认同的意见。
> 核心公式：**每条回应都要能让审稿人不必翻原稿，就看到"意见→你的处理→改后的原文（页码/行号）"。**

## 这个 skill 能做什么

| 阶段 | 你可以让我做的事 |
| --- | --- |
| 0. 心态与分诊 | 读懂决定信情绪、按 major/minor/R&R 定策略、把意见拆成可执行清单 |
| 1. 拆解决定信 | 区分编辑硬性要求 vs 审稿建议、必答项 vs 可选、抓住"决定性意见" |
| 2. 回应信结构 | 搭整体骨架：致谢开场 + 逐条编号 + 定位约定 + 结尾 |
| 3. 逐条三段式 | 每条：复述意见→说明修改→引用改后原文 + 页码/行号 |
| 4. 语气与外交 | 不卑不亢、感谢但不谄媚、坚定但不对抗 |
| 5. 同意并修改 | 接受意见时怎么写得到位、避免"假改" |
| 6. 礼貌反驳 | 不认同时如何有据 push back，而不惹恼审稿人 |
| 7. 冲突审稿人 | 两位审稿人意见打架时如何两全并请编辑裁断 |
| 8. 常见要求类型 | 补分析/补文献/理论深化/方法澄清/样本因果质疑/英语润色的应对套路 |
| 9. Cover letter | 给编辑的附信怎么写 |
| 10. 重投核对 | tracked changes、清单核对、时间管理、重投前自检 |
| 11. 句式库 | 高频英文回应句式 + 真实骨架案例 |

## 使用方式（重要：先读对应 reference 再动手）

每个环节都有一份详细子文档，**含判定标准、正反例、可套用句式和模板**。进入某个环节时**先 Read 对应文件再作答**——修回最容易在"漏答某条""假改""硬刚审稿人""改了但审稿人找不到"这些地方翻车。

- `references/00-mindset-and-triage.md` — 收到决定信后的心态、三类决定的策略差异、把所有意见拆成带编号的可执行清单
- `references/01-decision-letter-anatomy.md` — 读懂编辑决定信：编辑硬性要求 vs 审稿建议、必答 vs 可选、如何识别"决定录用与否的关键意见"
- `references/02-response-letter-structure.md` — 回应信整体结构与格式约定（编号体系、原文引用方式、颜色/引号规范、给编辑与各审稿人的分区）
- `references/03-point-by-point.md` — 逐条回应黄金三段式：复述意见→说明修改→引用改后原文+页码/行号；粒度与拆条
- `references/04-tone-and-diplomacy.md` — 语气校准：感谢、谦逊、坚定的平衡；该说和不该说的话
- `references/05-agreeing-revising.md` — 同意并修改：如何写得具体、可核查，避免"口头同意、实际没改"
- `references/06-disagreeing-respectfully.md` — 礼貌反驳：何时该 push back、如何用证据/文献/边界说明而非对抗，给编辑留裁量空间
- `references/07-conflicting-reviewers.md` — 审稿人意见冲突：如何两全、折中、或请编辑定夺而不得罪任何一方
- `references/08-request-types.md` — 常见要求类型逐类应对：补充分析、补文献、理论深化、方法/测量澄清、样本量与因果质疑、稳健性、英语润色
- `references/09-cover-letter.md` — 给编辑的 cover letter：结构、要点、与回应信的分工
- `references/10-resubmission-checklist.md` — 重投前：tracked changes vs 干净稿、逐条核对、时间管理与截止、常见退回原因自检
- `references/11-phrase-bank-cases.md` — 高频英文回应句式库（致谢/同意/反驳/冲突/补分析）+ 真实修回骨架案例

流程图与可视化：

- `diagrams/rebuttal-flow.md` — 从决定信到重投的流程、逐条三段式结构、同意/反驳/冲突的决策分支、语气光谱（Mermaid）

模板：

- `templates/response-letter-template.md` — 完整回应信模板（开场+分区+逐条+结尾）
- `templates/point-by-point-table.md` — 逐条回应工作表（意见—处理—改后原文—页码—状态）
- `templates/cover-letter-template.md` — 给编辑的 cover letter 模板
- `templates/phrase-bank.md` — 中英对照高频句式速查

## 核心工作原则（贯穿所有阶段）

1. **一条都不能漏**。审稿人每一点（哪怕一句话、一个小问题）都要有独立编号的回应。漏答是修回大忌。
2. **让审稿人零成本核实**。每条回应都**引用修改后的原文并给页码/行号**，让 ta 不必翻原稿就看到你改了。
3. **先感谢、再回应、后定位**。三段式：复述意见（表明你读懂了）→说明如何处理→贴改后原文。
4. **能改就改，不能改就有据地说清**。多数意见接受即可；确需反驳的，用证据/文献/研究边界，而非情绪对抗，并把最终裁量权留给编辑。
5. **语气不卑不亢**。感谢但不谄媚，自信但不傲慢，坚定但不防御。审稿人是在帮你。
6. **冲突意见要摊开**。两位审稿人打架时，说明你如何权衡、折中，或明确请编辑定夺，别偷偷只听一个。
7. **可核查、可追溯**。配合 tracked changes / 页行号，回应信与修改稿严格对应。

## 典型触发场景与首步动作

- "我收到 major revision，不知从哪下手" → 读 `00` + `01`，先分诊拆清单
- "回应信整体怎么排" → 读 `02`，套 `templates/response-letter-template.md`
- "每条到底怎么写" → 读 `03`，套逐条工作表
- "有一条我不同意，怎么办" → 读 `06`
- "两个审稿人要求相反" → 读 `07`
- "审稿人要我补一个分析/补文献/加理论" → 读 `08` 对应类型
- "cover letter 怎么写" → 读 `09`
- "重投前要检查什么" → 读 `10`
- "给我一些礼貌又地道的英文句式" → 读 `11`，套 `templates/phrase-bank.md`

## 与 ssci-writing skill 的关系

本 skill 专攻**投稿后的修回环节**（从决定信到重投）。若用户要的是**写稿本身**（选刊、research gap、IMRaD、摘要/引言/方法/结果写作、desk reject 规避），指向 `ssci-writing` skill。两者衔接：**用 ssci-writing 把稿子写好投出去，用本 skill 把审稿意见接住、改回去。**

> 注：本 skill 面向**期刊同行评审**；答辩（viva）意见回应逻辑相通（逐条、有据、可核查），可借用其三段式与语气原则，但答辩另有口头应对与委员会情境，必要时结合具体场景调整。

## 语言
默认用简体中文与用户交流。回应信正文按目标期刊语言产出（英文期刊给地道英文句式，中文期刊给中文），关键处中英对照。
